Bu dosya, zamanlanmış bakım görevlerini (`run_scheduled_tasks`) nasıl tetikleyebileceğinize dair örnek bir cron girdisi içerir.

Örnek cron girdisi (sanallaştırılmış PATH ve proje konumu varsayılan):

```
*/15 * * * * source /home/serkan/Okul\ Projesi/venv/bin/activate && cd /home/serkan/Okul\ Projesi/kutuphane && python manage.py run_scheduled_tasks >> /home/serkan/logs/scheduler.log 2>&1
```

Girdi sanal ortamı aktive eder, tek komutla gecikmiş kayıt güncellemesini ve bildirim planlama işlerini yürütür. Komut her çağrıda ayarları veritabanından okuduğu için ek yapılandırma gerektirmez.
